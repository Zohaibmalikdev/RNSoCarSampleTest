import {View, StyleSheet} from 'react-native';


export const lineSeperator = <View style={{ borderBottomColor: 'black', borderBottomWidth: StyleSheet.hairlineWidth, justifyContent: 'center',
alignItems: 'center' }} />;