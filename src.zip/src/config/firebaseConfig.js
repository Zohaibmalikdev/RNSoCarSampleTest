export const firebaseConfig = {
  databaseURL: 'https://rnsocarsample-default-rtdb.asia-southeast1.firebasedatabase.app/'
}
